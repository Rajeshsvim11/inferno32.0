module ONCCertificationG10TestKit
  VERSION = '3.2.0'.freeze
end
